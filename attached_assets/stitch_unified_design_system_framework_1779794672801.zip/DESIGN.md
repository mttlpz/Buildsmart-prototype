---
name: BuildSmart
version: 1.0.0
description: Industrial Construction Estimation & Price Intelligence Dashboard
colors:
  primary: '#EA580C'
  primary-hover: '#C2410C'
  surface: '#FFFFFF'
  background: '#F8FAFC'
  neutral: '#0F172A'
  neutral-muted: '#64748B'
  error: '#EF4444'
  warning: '#F59E0B'
  invalid: '#A855F7'
  duplicate: '#3B82F6'
  success: '#22C55E'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#5a4138'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#8e7166'
  outline-variant: '#e2bfb2'
  surface-tint: '#a73a00'
  on-primary: '#ffffff'
  primary-container: '#cc4900'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb599'
  secondary: '#5c5f61'
  on-secondary: '#ffffff'
  secondary-container: '#e0e3e5'
  on-secondary-container: '#626567'
  tertiary: '#005da8'
  on-tertiary: '#ffffff'
  tertiary-container: '#0076d2'
  on-tertiary-container: '#fdfcff'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb599'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7f2b00'
  secondary-fixed: '#e0e3e5'
  secondary-fixed-dim: '#c4c7c9'
  on-secondary-fixed: '#191c1e'
  on-secondary-fixed-variant: '#444749'
  tertiary-fixed: '#d4e3ff'
  tertiary-fixed-dim: '#a4c9ff'
  on-tertiary-fixed: '#001c39'
  on-tertiary-fixed-variant: '#004883'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
  border: '#E2E8F0'
typography:
  headline-lg:
    fontFamily: Inter, sans-serif
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
  body-md:
    fontFamily: Inter, sans-serif
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-sm:
    fontFamily: JetBrains Mono, monospace
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
rounded:
  sm: 4px
  md: 8px
  lg: 12px
  DEFAULT: 0.25rem
  xl: 0.75rem
  full: 9999px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  grid-gutter: 16px
components:
  data-grid-header:
    backgroundColor: '{colors.background}'
    textColor: '{colors.neutral}'
    typography: '{typography.label-sm}'
  action-button-primary:
    backgroundColor: '{colors.primary}'
    textColor: '{colors.surface}'
    rounded: '{rounded.md}'
---

## Overview
BuildSmart features an "Industrial-Precision Enterprise" aesthetic designed for construction professionals and estimators. The interface rejects flashy gradients, micro-interactions, and arbitrary rounded edges. It utilizes an ultra-clean, high-density dashboard structure to present large pricing grids efficiently. Visual depth is driven by flat 1px borders rather than soft shadows to preserve an editorial, tool-like utility weight.
## Colors
The palette leverages high-contrast functional color roles to assist rapid scanning:
- **BuildSmart Industrial Orange (#EA580C):** Used strictly for conversion points and system progression steps (e.g., "Advance: Map & Visualize").
- **Semantic Validation Tokens:** Used specifically in data audit workspaces to reflect parsed document states. They must never be mixed or swapped.
## Typography
Inter is used for all UI scaffolding, navigation structures, and input elements. Monospace font variants (JetBrains Mono) are strictly enforced for system items like Item Codes, SKUs, and raw Cost parameters to avoid character width alignment discrepancies.
## Layout & Spacing
Built entirely on a rigid 8px spatial grid ecosystem. Visual real estate is prioritized for maximum information density:
- Standard data matrices use tight row paddings (`8px` top/bottom).
- Split-screen workspaces employ a 75% wide main view paired with a sticky 25% side validation sidebar monitor.
## Components
- **Audit Cells:** Problematic data entries are visually highlighted using soft background tint variations matching their specific semantic error token. 
- **Action Footers:** Fixed positioning container anchoring navigation actions safely outside table scrolling containers.
## Do's and Don'ts
- **DO** keep the primary Orange button disabled until critical system blockers (`🔴 Missing Required`) read exactly zero rows.
- **DO** highlight entire table cell regions when errors exist rather than placing small indicator dots.
- **DON'T** use floating card styles or heavy drop-shadow elevations. Use a solid 1px border (#E2E8F0) to bound functional layout elements.
- **DON'T** try to automatically hide or silently "smart-fix" unmapped vendor lines; display all imported items directly in a raw staging state to keep full control in the user's hands.